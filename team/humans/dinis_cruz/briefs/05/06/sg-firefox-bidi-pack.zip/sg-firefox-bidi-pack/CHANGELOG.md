# Changelog

## 1.0.0 — initial release

The full pack:

- `docker/docker-compose.yml` — firefox + bidi-relay + mitmproxy stack
- `docker/Dockerfile.firefox-cli` — image for the CLI
- `python/firefox_bidi.py` — async BiDi client class
- `python/firefox_cli.py` — Typer CLI
- `scripts/install.sh` — bootstrap
- `scripts/restart.sh` — safe firefox+relay restart
- `scripts/ffcli.sh` — shell function helper
- `docs/` — architecture, usage, troubleshooting, background

### Verified working

- BiDi session creation against Firefox 145
- Navigation, get_url, get_title, get_html, get_text
- Screenshot capture
- Arbitrary JS evaluation with promise awaiting
- Tab management (new_tab, close_tab, contexts)
- Cookie listing
- History (reload, back, forward)
- CLI smoke test from sibling container in `sg-firefox_default`
- Connection from `--network host` containers

### Known operational quirks

- `docker compose restart firefox` silently breaks the relay; use
  `scripts/restart.sh` instead.
- Firefox only allows one active BiDi session at a time; concurrent CLI
  invocations may collide.

### Possible future work

- Move socat into the firefox image as an s6 service (eliminates the
  restart fragility).
- Add wait-for-element helpers on top of `eval` for ergonomics.
- More event subscriptions (network interception helpers).
- Pre-built image published to a registry for `docker pull` instead of
  local `docker build`.
