# Security notes

This pack includes a few operational security considerations worth flagging.
None of them are exotic — but if you're deploying this beyond a personal
dev environment, read through.

## Set a real `WEB_AUTHENTICATION_PASSWORD`

`docker/docker-compose.yml` ships with `CHANGE-ME-BEFORE-USING` as a
placeholder. This controls access to the noVNC view of Firefox. Anyone
with this password can drive the browser through the web UI as if they
were sitting at the keyboard.

Generate something strong:

```sh
openssl rand -base64 24
```

And set it via env var or `.env` file rather than committing the value:

```yaml
WEB_AUTHENTICATION_PASSWORD: "${FIREFOX_NOVNC_PASSWORD}"
```

```sh
# .env (gitignored)
FIREFOX_NOVNC_PASSWORD=<your generated password>
```

## The BiDi port has no auth

Firefox's Remote Agent (`9222` inside the container, `9223` on the docker
network via the relay, `9222` on the host via the published port) has
**no authentication and no encryption**. Anyone who can reach it can
drive the browser, read cookies, capture the screen, exfiltrate stored
passwords from the profile.

What this means in practice:

- **Don't expose the BiDi host port to the public internet.** Bind it to
  `127.0.0.1` if your client runs on the same host, or remove the host
  port mapping entirely if your client is in a sibling container.
- **The docker network is a trust boundary.** Anyone who can run a
  container on `sg-firefox_default` can drive Firefox.
- **Treat the firefox container as if it had your noVNC password.**
  Because effectively, anyone driving it can submit forms, log in, etc.

To restrict the host-side BiDi port to local-only (recommended):

```yaml
ports:
  - "127.0.0.1:9222:9223"   # was "9222:9223"
```

## Firefox's profile is shared between human and scripts

Single Firefox process means a single profile means a single cookie jar.
Scripts pick up cookies, history, saved logins from human use, and vice
versa. That's the whole point — but be aware:

- Don't sign into your personal accounts via noVNC if scripts can pull
  cookies and ship them elsewhere.
- A compromised script (malicious dependency, e.g.) can dump the entire
  browser profile.
- Use a dedicated browser profile for automation; keep personal browsing
  elsewhere.

## `navigator.webdriver === true`

Whenever Firefox's Remote Agent is enabled, `navigator.webdriver` is `true`.
Sites that fingerprint for automation will detect this. This isn't really
a security issue (you're driving your own browser), but it does affect:

- Anti-bot challenges may block you
- Some sites change behaviour for automated browsers
- A/B testing tools may exclude you from experiments

## mitmproxy as part of the stack

If you're using the included mitmproxy service for network inspection,
remember that mitmproxy decrypts TLS by installing its own CA cert into
the Firefox profile. That cert is trusted **for everything** — anyone
with the cert + private key can MITM all of that browser's HTTPS traffic.

Treat `/opt/sg-firefox/mitmproxy-data/` as sensitive. Don't commit it,
don't share it, don't reuse it across environments.

## What this pack does NOT include

- TLS / encryption on the BiDi WebSocket (the protocol doesn't support it
  natively; you'd need stunnel or nginx-as-TLS-terminator)
- Auth on the BiDi WebSocket (same)
- Rate limiting (a runaway script can hammer the browser to OOM)
- Audit logging (BiDi commands are not logged anywhere by default)

If your deployment needs any of these, layer them on top.

## Reporting a security issue

If you find a vulnerability in this pack, open an issue or contact the
repository maintainer privately. Please don't post exploits publicly
before coordinating.
