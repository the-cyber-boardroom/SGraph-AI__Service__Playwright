# Usage

This is the reference for actually using the stack day-to-day. There are two
ways in: the **CLI** (great for shell glue and one-off commands) and the
**Python client class** (better for multi-step workflows and long-running
sidecars).

## Setting up `ffcli` in your shell

After `./scripts/install.sh` has run, source the helper:

```sh
# in ~/.bashrc or ~/.zshrc
source /path/to/sg-firefox-bidi-pack/scripts/ffcli.sh
```

Then in a fresh shell:

```sh
ffcli session
```

If that prints a session id, user agent, and current URL — you're set.

## Two flavours of `ffcli`

The shell helper exposes two functions:

### `ffcli` — production mode

Uses the prebuilt `firefox-cli` image. Fast (~200ms startup), fixed code.
Rebuild the image to pick up changes:

```sh
docker build -t firefox-cli -f docker/Dockerfile.firefox-cli .
```

### `ffcli-dev` — hot-reload mode

Bind-mounts your local `firefox_bidi.py` and `firefox_cli.py` into a
generic Python image. Slower (~5s for pip install per call) but reflects
code changes immediately. Useful while extending the client.

```sh
export FFCLI_SRC_DIR=/path/to/sg-firefox-bidi-pack/python
ffcli-dev open https://example.com
```

## CLI command reference

```sh
ffcli --help                   # full command list
ffcli <command> --help         # detail per command
```

| Command | Purpose | Notes |
|---|---|---|
| `session` | Connection diagnostic | session id, UA, tab count, current URL |
| `open URL` | Navigate | Returns final URL after redirects |
| `url` | Print current URL | |
| `title` | Print `document.title` | |
| `text` | Print `document.body.innerText` | Newline-friendly |
| `html [-o FILE]` | Get outerHTML | Default to stdout for piping |
| `screenshot [-o FILE] [--full-page]` | PNG capture | Default file: `screenshot.png` |
| `eval EXPR` | Evaluate JS expression | Wrap statements in IIFEs |
| `cookies` | List cookies | Tab-separated by default |
| `contexts` | List tabs | id and URL per line |
| `new-tab [--url URL]` | Open tab | Prints new context id |
| `close-tab CTX_ID` | Close tab | Get id from `contexts` |
| `reload` / `back` / `forward` | History | |

### Global options (before subcommand)

| Option | Default | Notes |
|---|---|---|
| `--host` | `firefox` | Or `$FIREFOX_HOST` |
| `--port` | `9223` | Or `$FIREFOX_PORT` |
| `--json` | off | Structured JSON for piping into `jq` |
| `--wait` | `complete` | `none` \| `interactive` \| `complete` |

## CLI examples

### Basic flow

```sh
ffcli open https://news.ycombinator.com
ffcli title
ffcli url
ffcli html -o /tmp/hn.html
ffcli screenshot -o /tmp/hn.png --full-page
```

### Run JavaScript

```sh
ffcli eval "document.querySelectorAll('.athing').length"
ffcli eval "navigator.userAgent"
ffcli eval "Array.from(document.querySelectorAll('.titleline > a')).map(a => a.textContent).slice(0,5)"
```

### Wait for something to load

`eval` with a promise + `--wait`:

```sh
ffcli eval "new Promise(r => { const i = setInterval(() => { if (document.querySelector('.loaded')) { clearInterval(i); r(true); } }, 100); })"
```

The CLI awaits the promise by default (use `--no-await` to skip).

### JSON output for scripts

```sh
ffcli --json title
# {
#   "...": "Some Title"
# }

ua=$(ffcli --json eval "navigator.userAgent" | jq -r .)
echo "$ua"
```

### Pipe HTML through tools

```sh
ffcli html | grep -c '<a '             # count links
ffcli html > current_page.html         # save to file (raw mode)
ffcli html | python -c 'import sys, html2text; print(html2text.html2text(sys.stdin.read()))'
```

### Tab management

```sh
ffcli contexts
# 397f10b8-44f8-4d8a-aefb-28d93beb15bf	https://example.com/

new_id=$(ffcli new-tab --url https://google.com)
ffcli contexts                        # now 2 tabs
ffcli close-tab "$new_id"
```

## Recipes

### Capture a page after manual login

```sh
ffcli open https://github.com/login
echo "Sign in via the noVNC view, then press Enter"
read
ffcli url             # confirm we're past the login wall
ffcli html -o logged-in.html
ffcli screenshot -o logged-in.png
```

This is the killer feature of running scripts and humans against the same
browser: human handles captchas, MFA, weird login flows; the script picks
up afterwards. You can't do this with a separate headless browser.

### Quick scrape

```sh
#!/bin/sh
ffcli open https://news.ycombinator.com
titles=$(ffcli --json eval "Array.from(document.querySelectorAll('.titleline > a')).slice(0,5).map(a => a.textContent)")
echo "$titles" | jq -r '.[]'
```

### Watch a long-running page

```sh
ffcli open https://something-slow.example
while true; do
    state=$(ffcli eval "document.querySelector('.status')?.textContent ?? 'unknown'")
    echo "$(date +%T) $state"
    [ "$state" = "done" ] && break
    sleep 5
done
```

## Python client

The CLI is fine for one-off commands. For multi-step workflows you'll usually
want the client class directly — one BiDi session shared across all commands,
no per-command setup overhead.

### Basic shape

```python
import asyncio
from firefox_bidi import FirefoxBiDi

async def main():
    async with FirefoxBiDi(host="firefox", port=9223) as ff:
        await ff.open_url("https://example.com")
        title = await ff.get_title()
        html = await ff.get_html()
        png = await ff.screenshot()
        # ... many more commands, one session

asyncio.run(main())
```

### Method index

```
# Lifecycle
ff.connect() / ff.close()        # or use `async with`
ff.subscribe(events, contexts=)  # BiDi events
ff.on(method, handler)           # event callbacks

# Navigation
ff.open_url(url, *, context=, wait=)
ff.reload(context=, wait=)
ff.go_back(context=)
ff.go_forward(context=)

# Inspection
ff.get_url(context=)
ff.get_title(context=)
ff.get_html(context=)
ff.get_text(context=)
ff.eval(expression, *, context=, await_promise=True)
ff.screenshot(context=, *, full_page=False)
ff.get_cookies(context=)
ff.get_contexts()                # all tabs
ff.current_context()             # first top-level tab id

# Tab management
ff.new_tab(url=None)
ff.close_tab(context)

# Escape hatch
ff._call("namespace.method", {...})  # any BiDi command
```

### `eval` is the universal escape hatch

If a method you want isn't on the class, `eval` is almost always enough:

```python
# Form fill
await ff.eval("""
    document.querySelector('#email').value = 'me@example.com';
    document.querySelector('#submit').click();
""")
# Wait — this is a statement, not an expression. Wrap in an IIFE:
await ff.eval("""
    (() => {
        document.querySelector('#email').value = 'me@example.com';
        document.querySelector('#submit').click();
    })()
""")

# Wait for an element
await ff.eval("""
    new Promise(r => {
        const interval = setInterval(() => {
            if (document.querySelector('.loaded')) {
                clearInterval(interval);
                r(true);
            }
        }, 100);
    })
""")  # await_promise=True (default)

# Extract structured data
items = await ff.eval("""
    Array.from(document.querySelectorAll('.item')).map(el => ({
        title: el.querySelector('.title')?.textContent,
        url: el.querySelector('a')?.href,
    }))
""")
```

`eval` returns Python primitives where possible (strings, numbers, bools,
lists, dicts of those). Complex JS objects (Date, RegExp, Map, etc.) come
back as the raw BiDi RemoteValue dict — usually you'd convert them in JS
first (`someDate.toISOString()`).

### Sharing a session across calls

The client is happiest used long-lived. Don't do this:

```python
# BAD — connects, runs one command, disconnects, repeats
for url in urls:
    async with FirefoxBiDi() as ff:
        await ff.open_url(url)
        # ...
```

Do this:

```python
# GOOD — one session, many commands
async with FirefoxBiDi() as ff:
    for url in urls:
        await ff.open_url(url)
        # ...
```

Firefox only allows one active BiDi session at a time. Reconnecting per
URL means each connect waits for the previous session to be cleaned up.

### Concurrency

The reader task demuxes responses by id, so multiple coroutines can call
methods concurrently:

```python
async with FirefoxBiDi() as ff:
    await ff.open_url("https://example.com")
    title, url, ua = await asyncio.gather(
        ff.get_title(),
        ff.get_url(),
        ff.eval("navigator.userAgent"),
    )
```

That said: there is exactly one Firefox tab being driven by default. If
two coroutines both call `open_url` concurrently, the last one wins.

### Subscribing to events

```python
async with FirefoxBiDi() as ff:
    await ff.subscribe(["log.entryAdded", "network.responseStarted"])

    def on_log(params):
        print("[console]", params.get("text"))

    def on_response(params):
        resp = params.get("response", {})
        print(f"[net] {resp.get('status')} {resp.get('url')}")

    ff.on("log.entryAdded", on_log)
    ff.on("network.responseStarted", on_response)

    await ff.open_url("https://example.com")
    await asyncio.sleep(5)  # let events flow
```

Full BiDi event list:
https://w3c.github.io/webdriver-bidi/

## Connecting from `--network host` instead of the docker network

If you're testing from the host directly (e.g., from a Python script on
the EC2 instance, not in a container), use the host-network form:

```python
async with FirefoxBiDi(host="localhost", port=9222) as ff:
    ...
```

Or:

```sh
FIREFOX_HOST=localhost FIREFOX_PORT=9222 python firefox_cli.py session
```

Either form works because the Host header (`localhost:9222`) is in
Firefox's `--remote-allow-hosts` allowlist.

## When to use what

| Situation | Use |
|---|---|
| One-off shell commands, glue scripts | `ffcli` |
| Pipe HTML/JSON into other tools | `ffcli --json` + `jq` |
| Multi-step workflow with shared state | Python `FirefoxBiDi` |
| Long-running sidecar service | Python `FirefoxBiDi` (one instance, many commands) |
| Reactive automation (subscribe to events) | Python `FirefoxBiDi` (CLI doesn't expose subscribe) |
| Quick experimentation while extending the client | `ffcli-dev` |

## Things to keep in mind

- **One session at a time.** Don't run two CLI processes concurrently —
  one will fail with `Maximum number of active sessions`. Use the Python
  class for parallelism.
- **`navigator.webdriver` is `true`.** Anti-bot fingerprinting will
  detect this. Not a problem for most use cases.
- **No auth on the BiDi port.** The relay exposes `0.0.0.0:9223` inside
  the firefox container. Don't expose it to untrusted networks. Your
  WEB_AUTHENTICATION on noVNC doesn't apply to BiDi.
- **`eval` is JS expressions, not statements.** Wrap in IIFE if needed.
- **The driving and the watching go to the same browser.** This is a
  feature, not a bug, but be aware that automation moves the human's
  cursor / scrolls / changes tabs.
