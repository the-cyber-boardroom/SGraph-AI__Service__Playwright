# Troubleshooting

A pretty comprehensive list of failure modes I encountered building this,
and what each one looks like.

## Connection problems

### `ConnectionRefusedError: [Errno 111] Connect call failed (..., 9223)`

The relay is dead. This usually happens after `docker compose restart firefox`
because the relay shares Firefox's network namespace and the namespace gets
recreated.

```sh
# Check
docker exec sg-firefox-firefox-1 netstat -tlnp 2>/dev/null | grep -E '9222|9223'
```

You should see two lines: `127.0.0.1:9222` (Firefox) and `0.0.0.0:9223`
(socat). If only Firefox's line is there, the relay's listener is gone.

**Fix:**

```sh
./scripts/restart.sh
```

Or manually:

```sh
docker compose -f /opt/sg-firefox/docker-compose.yml up -d --force-recreate firefox bidi-relay
```

**Don't:** use `docker compose restart firefox`. That doesn't restart the
relay and you'll keep hitting this.

### `ConnectionRefusedError` when connecting to port 9222

If you're connecting from a sibling container on the docker network, the
port is **9223**, not 9222. Port 9222 is only published to the host.

| Where you're calling from | Use |
|---|---|
| Sibling container on `sg-firefox_default` | `firefox:9223` |
| `--network host` container | `localhost:9222` |
| EC2 host shell directly | `localhost:9222` |

### `websockets.exceptions.InvalidStatus: HTTP 400`

Firefox's Remote Agent rejected the WebSocket upgrade. The most common cause
is the `Host:` header. The Python client handles this automatically, but if
you're connecting with raw `websockets.connect(url)` without the IP+sock
trick, you'll see this.

Verify what Firefox is rejecting:

```sh
docker run --rm --network sg-firefox_default curlimages/curl:latest \
  curl -v -i \
  -H "Connection: Upgrade" \
  -H "Upgrade: websocket" \
  -H "Sec-WebSocket-Version: 13" \
  -H "Sec-WebSocket-Key: dGhlIHNhbXBsZSBub25jZQ==" \
  http://firefox:9223/session
```

Body of the 400 will tell you what's wrong. Some known rejections:

| Body | Cause |
|---|---|
| `Bad request` | Host header rejection (most common) |
| `The handshake request must have a Sec-WebSocket-Key header` | You forgot the WebSocket headers |
| `Invalid request` | Path doesn't match BiDi endpoint; should be `/session` |

**Fix for Host rejection:** use the Python client class — it does the IP
lookup + sock trick. Don't try to fix `--remote-allow-hosts` in the compose
because it doesn't accept entries with port numbers.

### `connect timeout` or just hangs

Firefox crashed or didn't start. Check:

```sh
docker compose -f /opt/sg-firefox/docker-compose.yml ps
docker compose -f /opt/sg-firefox/docker-compose.yml logs firefox --tail 100
```

Firefox occasionally needs a `--force-recreate` to come back from a bad
state (corrupted profile, leftover lock files in `/config/profile`).

## Session problems

### `BiDiError [session not created]: Maximum number of active sessions`

A previous client created a session and didn't end it cleanly. Firefox only
allows one session at a time, and there's no way to "take over" from outside
the session.

**Fix (preferred):** make sure your client uses `async with FirefoxBiDi(...)`
or calls `await ff.close()` — both end the session.

**Fix (when you're stuck):**

```sh
./scripts/restart.sh
```

This kills Firefox, taking the dangling session with it.

If you ran a CLI command and it crashed mid-flight, the session may still be
hanging. The CLI does its best to end the session in a `finally` block, but
hard kills (kill -9, container OOM) bypass that.

### `BiDiError [invalid session id]: WebDriver session does not exist`

You're calling commands after the session ended (or was never created
successfully). Reconnect:

```python
async with FirefoxBiDi(...) as ff:
    ...  # fresh session
```

## Eval problems

### `BiDiError [script.exception]: ReferenceError: ... is not defined`

Your JS expression references something that doesn't exist on the page.
Common cause: navigating to a page that doesn't have the selector you're
looking for.

### `BiDiError [script.exception]: TypeError: ...`

Your JS expression has a bug. The full stack trace is in `e.stacktrace`.

### `eval` returns a weird dict instead of a value

You returned a complex JS object (Date, Map, RegExp, DOM Node, etc.). The
client unwraps primitives but leaves complex types as the raw BiDi
RemoteValue. Convert in JS first:

```python
# BAD — returns a Date wrapped in BiDi metadata
date = await ff.eval("new Date()")

# GOOD — returns an ISO string
date = await ff.eval("new Date().toISOString()")

# BAD — returns a NodeList wrapped in BiDi metadata
nodes = await ff.eval("document.querySelectorAll('.item')")

# GOOD — returns a list of strings
texts = await ff.eval("Array.from(document.querySelectorAll('.item')).map(n => n.textContent)")
```

### `eval` hangs forever

You returned a promise that never resolves. The client awaits promises by
default. Pass `await_promise=False` to skip awaiting, or fix the expression
so the promise eventually resolves.

## Network / DNS problems

### `socket.gaierror: [Errno -2] Name or service not known`

The Python client can't resolve the firefox hostname. Check:

- The container is on the right docker network (`sg-firefox_default`)
- `FIREFOX_HOST` is set to `firefox` (not the container ID or IP)
- The firefox container is actually running

Quick check from any container on the network:

```sh
nslookup firefox
# or
getent hosts firefox
```

### Firefox can't reach the internet

The compose has firefox going through `mitmproxy` for outbound requests
(if configured that way). If mitmproxy is down or misconfigured, Firefox
will fail to load pages.

```sh
docker compose -f /opt/sg-firefox/docker-compose.yml logs mitmproxy --tail 50
```

To bypass mitmproxy temporarily, edit Firefox's proxy preferences in noVNC
or remove the proxy env vars from compose.

## Compose problems

### `bidi-relay` keeps showing "Up" but doesn't work

This is the namespace-sharing fragility. The container's main process
(socat) is alive, but its listener is bound to a network namespace that
no longer exists. Docker doesn't notice this.

Symptoms:
- `docker compose ps` shows bidi-relay as Up
- `docker compose logs bidi-relay` is empty
- `netstat` inside firefox shows no `0.0.0.0:9223`

Fix: `./scripts/restart.sh`.

### Image pull fails for `alpine/socat`

Pretty rare but it happens. Pin a specific tag in compose:

```yaml
bidi-relay:
  image: alpine/socat:1.7.4.4
```

### Port 9222 already in use on host

Some other process on the EC2 instance is using 9222. Either kill that
process, or change the compose port mapping:

```yaml
ports:
  - "19222:9223"   # was 9222:9223
```

Then connect to host:19222 instead.

## Diagnostic commands

When in doubt, run these and look:

```sh
# 1. Compose state
docker compose -f /opt/sg-firefox/docker-compose.yml ps

# 2. Both listeners alive in firefox netns?
docker exec sg-firefox-firefox-1 netstat -tlnp 2>/dev/null | grep -E '9222|9223'

# 3. Firefox actually started with the right flags?
docker exec sg-firefox-firefox-1 ps aux | grep firefox | head -1

# 4. Relay process alive?
docker exec sg-firefox-bidi-relay-1 ps aux

# 5. Logs
docker compose -f /opt/sg-firefox/docker-compose.yml logs firefox --tail 50
docker compose -f /opt/sg-firefox/docker-compose.yml logs bidi-relay --tail 20

# 6. Smoke test from a sibling container
docker run --rm --network sg-firefox_default \
    -e FIREFOX_HOST=firefox -e FIREFOX_PORT=9223 \
    firefox-cli session

# 7. Smoke test from --network host
docker run --rm --network host \
    -e FIREFOX_HOST=localhost -e FIREFOX_PORT=9222 \
    firefox-cli session
```

If 6 fails but 7 works: it's the docker-network path (Host header issue
in your code, or relay dead).

If 7 fails but 6 works: weird, but probably a host-port mapping conflict.

If both fail: Firefox or the relay is broken; check 1-5.
