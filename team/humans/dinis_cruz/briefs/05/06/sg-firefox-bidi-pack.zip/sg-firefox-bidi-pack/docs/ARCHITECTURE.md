# Architecture

## The problem

`jlesage/firefox` runs a vanilla Firefox inside a virtual desktop, exposed to
humans via noVNC. We want scripts (running in another container on the same
docker network) to drive that same Firefox programmatically — navigate, run JS,
capture screenshots, intercept network — while keeping the human-visible
noVNC view intact.

The catch is Firefox's automation protocols all bind to loopback only:

- **Marionette** (`:2828`) — Firefox's native automation protocol. Hardcoded
  `127.0.0.1`. The `--marionette-host` CLI flag is silently ignored.
- **WebDriver BiDi / CDP** (`:9222`) — Modern protocol via the Remote Agent.
  Hardcoded `127.0.0.1` via a `LOOPBACKS.includes(host)` check in the source.
  No flag overrides this.

Both are deliberate security choices. They're correct, but they make our
remote-control use case awkward.

## The solution

```
┌─────────────────────────────── docker network: sg-firefox_default ─────────────────────────────┐
│                                                                                                  │
│  ┌─── firefox container (jlesage/firefox) ───────────────────────┐                              │
│  │                                                                │                              │
│  │  Firefox 145 (loopback only):                                  │                              │
│  │    127.0.0.1:9222    ← BiDi WebSocket (Remote Agent)           │                              │
│  │    127.0.0.1:5900    ← Xvnc (used by noVNC)                    │                              │
│  │                                                                │                              │
│  │  noVNC HTTPS:                                                  │                              │
│  │    0.0.0.0:5800      ← human view (humans browse here)         │                              │
│  │                                                                │                              │
│  │  ───────────────────────────────────────────────────────────   │                              │
│  │  bidi-relay container (alpine/socat),                          │                              │
│  │  shares this container's network namespace:                    │                              │
│  │    0.0.0.0:9223 ──fork──→ 127.0.0.1:9222                       │                              │
│  │  ───────────────────────────────────────────────────────────   │                              │
│  │                                                                │                              │
│  │   eth0 IP: e.g. 172.24.0.3 (varies)                            │                              │
│  └────────────────────────────────────────────────────────────────┘                              │
│              ▲                                                                                    │
│              │  ws://firefox:9223/session                                                         │
│              │  Host header workaround: socket goes to firefox:9223,                              │
│              │  URL on the wire claims ws://localhost:9222/session                                │
│              │                                                                                    │
│  ┌─── python sidecar / CLI container ────┐    ┌─── mitmproxy ────────┐                           │
│  │  firefox_bidi.py / firefox_cli.py     │    │  intercepts firefox  │                           │
│  │  (asyncio + websockets)               │    │  network traffic if  │                           │
│  └───────────────────────────────────────┘    │  configured to use   │                           │
│                                                │  it as proxy         │                           │
│                                                └──────────────────────┘                           │
│                                                                                                   │
└──────────────────────────────────────────────────────────────────────────────────────────────────┘

External access (host published ports):
  443  → firefox:5800   (noVNC HTTPS for humans)
  9222 → firefox:9223   (BiDi via the relay; reachable from `--network host`)
  8081 → mitmproxy:8081 (mitmweb UI)
```

## Components in detail

### Firefox (in `jlesage/firefox`)

Started by jlesage's s6 init system with these arguments:

```
--remote-debugging-port=9222
--remote-allow-hosts=firefox,firefox:9223,localhost,localhost:9222,127.0.0.1,127.0.0.1:9222
```

The Remote Agent inside Firefox:

- Binds `127.0.0.1:9222` regardless of any flag we pass
- Serves the WebDriver BiDi protocol on `ws://127.0.0.1:9222/session`
- Rejects WebSocket upgrades whose `Host:` header isn't in the allowlist
- Has no auth/encryption — anyone who can reach the loopback can drive
  the browser

### bidi-relay (alpine/socat sidecar)

Compose definition:

```yaml
bidi-relay:
  image: alpine/socat
  network_mode: "service:firefox"
  command: TCP-LISTEN:9223,fork,reuseaddr TCP:127.0.0.1:9222
```

The key piece is `network_mode: "service:firefox"`. The relay container
shares Firefox's network namespace, so its `127.0.0.1` is Firefox's
`127.0.0.1`. socat doesn't need to be installed inside the firefox image
itself, and there's no permission/profile management to worry about.

Containers using shared namespaces can't declare their own `ports:`, so
the `9222:9223` host port mapping is on the firefox service.

### Python client (`firefox_bidi.py`)

A thin asyncio wrapper around the BiDi WebSocket:

- Maintains one long-lived WebSocket and one BiDi session
- Background reader task demuxes incoming messages by `id` (responses)
  or by `method` (events)
- High-level methods: `open_url`, `get_html`, `eval`, `screenshot`, etc.
- Async context manager for clean session lifecycle

### CLI (`firefox_cli.py`)

A Typer wrapper around the client class. Each subcommand creates and
ends its own BiDi session. That makes shell-glue automation easy at the
cost of ~200ms connection overhead per command.

## Two header workarounds you should understand

These both come up because Firefox's allowlist matching is more strict than
we'd like.

### Why we override the `Host:` header

Firefox's `--remote-allow-hosts` does **exact string matching** on the
full `Host:` header value, including the port. Despite documentation
suggesting it takes hostnames, the reality is:

- `Host: localhost:9222` matches list entry `localhost:9222` ✓
- `Host: firefox:9223` does NOT match list entry `firefox` (no port)
- `Host: firefox:9223` does NOT match list entry `firefox:9223` either
  (firefox seems to drop entries containing colons during parsing)

The Python client works around this by:

1. Resolving the Firefox container's IP itself (`socket.gethostbyname`)
2. Opening a TCP socket directly to `<resolved IP>:9223`
3. Telling the websockets library the URL is `ws://localhost:9222/session`
4. Passing the open socket via `sock=...` so websockets uses the existing
   connection rather than opening a new one

The result: socket goes to the relay, but the HTTP upgrade request says
`Host: localhost:9222`, which Firefox accepts.

### Why the relay is in firefox's namespace, not its own container

If we ran socat in its own network namespace and pointed it at
`firefox:9222`, Firefox wouldn't be reachable — port 9222 is loopback only.
We'd hit a connection refused.

By sharing namespaces, socat sees Firefox's loopback as its own and can
forward freely. The downside is the lifecycle coupling: when Firefox
restarts, the namespace is recreated and socat's listener silently dies.

Mitigation: use `scripts/restart.sh` instead of `docker compose restart firefox`.
The script forces both services to recreate together.

A long-term improvement would be moving socat as an s6 service inside
the firefox image itself. The pre-existing `socat` for port 2828 in the
original investigation showed this pattern works.

## What we're NOT doing

A few non-paths worth documenting so future readers don't waste time:

- **Marionette directly.** Same loopback problem, plus Playwright/Selenium
  tooling is more painful than just talking BiDi.
- **CDP via `--remote-debugging-port`.** Firefox 145 dropped CDP entirely;
  the port now serves BiDi only.
- **`--remote-allow-origins` / `--remote-allow-hosts` to "fix" the binding.**
  These are header allowlist flags, not bind-address flags. Firefox literally
  cannot be made to bind anywhere but loopback for these protocols.
- **Selenium 4 BiDi.** Selenium's BiDi support runs through geckodriver, which
  defeats the point of going BiDi-direct. Direct WebSocket is simpler.
- **Playwright `connect_over_cdp`.** Chromium-only. Doesn't work with Firefox.
- **Playwright `firefox.connect`.** Requires a Playwright-managed (patched)
  Firefox launched via `playwright launchServer`, not vanilla Firefox.
