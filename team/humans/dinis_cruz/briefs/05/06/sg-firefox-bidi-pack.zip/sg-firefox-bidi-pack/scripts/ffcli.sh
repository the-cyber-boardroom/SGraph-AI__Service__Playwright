# ffcli.sh — shell function for invoking the Firefox BiDi CLI
#
# Source this file in your ~/.bashrc or ~/.zshrc:
#
#     source /path/to/ffcli.sh
#
# Then use ffcli directly:
#
#     ffcli session
#     ffcli open https://example.com
#     ffcli title
#     ffcli html -o page.html
#
# Prerequisites:
#   1. The sg-firefox compose stack is running.
#   2. The firefox-cli image is built:
#        docker build -t firefox-cli -f docker/Dockerfile.firefox-cli .
#   3. (Optional) Override defaults via env vars before sourcing:
#        export FFCLI_NETWORK=sg-firefox_default
#        export FFCLI_FIREFOX_HOST=firefox
#        export FFCLI_FIREFOX_PORT=9223
#        export FFCLI_IMAGE=firefox-cli
#        export FFCLI_SUDO=sudo   # set to empty if your user can run docker

ffcli() {
    local network="${FFCLI_NETWORK:-sg-firefox_default}"
    local host="${FFCLI_FIREFOX_HOST:-firefox}"
    local port="${FFCLI_FIREFOX_PORT:-9223}"
    local image="${FFCLI_IMAGE:-firefox-cli}"
    local docker_cmd="${FFCLI_SUDO-sudo} docker"

    $docker_cmd run --rm -i \
        --network "$network" \
        -e FIREFOX_HOST="$host" \
        -e FIREFOX_PORT="$port" \
        "$image" "$@"
}

# Convenience: run from a hot-reloaded source tree (no rebuild needed)
# Useful while developing changes to firefox_bidi.py / firefox_cli.py.
ffcli-dev() {
    local network="${FFCLI_NETWORK:-sg-firefox_default}"
    local host="${FFCLI_FIREFOX_HOST:-firefox}"
    local port="${FFCLI_FIREFOX_PORT:-9223}"
    local docker_cmd="${FFCLI_SUDO-sudo} docker"
    local src_dir="${FFCLI_SRC_DIR:-$(pwd)/python}"

    if [ ! -f "$src_dir/firefox_cli.py" ]; then
        echo "ffcli-dev: firefox_cli.py not found in $src_dir" >&2
        echo "Set FFCLI_SRC_DIR to the directory containing firefox_bidi.py and firefox_cli.py" >&2
        return 1
    fi

    $docker_cmd run --rm -i \
        --network "$network" \
        -v "$src_dir/firefox_bidi.py:/work/firefox_bidi.py:ro" \
        -v "$src_dir/firefox_cli.py:/work/firefox_cli.py:ro" \
        -w /work \
        -e FIREFOX_HOST="$host" \
        -e FIREFOX_PORT="$port" \
        python:3.12-slim \
        bash -c "pip install -q typer websockets && python firefox_cli.py $*"
}
