# sg-firefox BiDi pack

A complete stack for remotely driving the Firefox in `jlesage/firefox` via
WebDriver BiDi — without Selenium, Playwright, or geckodriver.

A human can watch and interact with the same browser via noVNC while scripts
drive it programmatically.

## What's in here

```
sg-firefox-bidi-pack/
├── README.md                        ← you are here
├── docker/
│   ├── docker-compose.yml           ← the firefox + bidi-relay + mitmproxy stack
│   └── Dockerfile.firefox-cli       ← image for the CLI
├── python/
│   ├── firefox_bidi.py              ← async BiDi client class
│   └── firefox_cli.py               ← Typer CLI wrapping the client
├── scripts/
│   ├── install.sh                   ← one-shot bootstrap
│   ├── restart.sh                   ← safe firefox+relay restart
│   └── ffcli.sh                     ← shell function for invoking the CLI
└── docs/
    ├── ARCHITECTURE.md              ← how the pieces fit together
    ├── USAGE.md                     ← end-user guide for the CLI and Python class
    ├── TROUBLESHOOTING.md           ← when things go wrong
    └── BACKGROUND.md                ← why this design (Marionette/CDP/BiDi history)
```

## Quick start

From the root of the unpacked pack:

```sh
./scripts/install.sh
```

That builds the `firefox-cli` image, brings up the stack, and runs an
end-to-end smoke test. After it finishes, source the shell helper:

```sh
source scripts/ffcli.sh
```

Then drive Firefox:

```sh
ffcli open https://example.com
ffcli title
ffcli screenshot -o /tmp/shot.png
ffcli eval "document.querySelectorAll('a').length"
```

If you keep the noVNC view open at `https://<host>:443` while running these,
you'll see the same tab respond to each command in real time.

## Architecture in 30 seconds

```
┌─────────────────────────── docker network ───────────────────────────┐
│                                                                       │
│   ┌─ firefox container ────────────────┐    ┌─ python sidecar ────┐  │
│   │  Firefox (loopback only):          │    │  firefox_bidi /     │  │
│   │    127.0.0.1:9222 ← BiDi WebSocket │    │  firefox_cli        │  │
│   │                                    │    │                     │  │
│   │  socat (bidi-relay sidecar,        │ ←─ │  ws://firefox:9223  │  │
│   │   shares firefox's netns):         │    │  /session           │  │
│   │    0.0.0.0:9223 → 127.0.0.1:9222   │    │  + Host header      │  │
│   │                                    │    │    workaround       │  │
│   │  noVNC (5800) ← human view         │    └─────────────────────┘  │
│   └────────────────────────────────────┘                              │
│                                                                       │
└───────────────────────────────────────────────────────────────────────┘
```

Firefox's Remote Agent hardcodes loopback binding. The `bidi-relay` container
runs socat in Firefox's network namespace and exposes the WebSocket on the
docker network. The Python client uses a Host-header workaround because
Firefox's `--remote-allow-hosts` doesn't accept entries with port numbers.

Full details in [docs/ARCHITECTURE.md](docs/ARCHITECTURE.md).

## Documentation

- **[docs/USAGE.md](docs/USAGE.md)** — How to drive Firefox: CLI commands, Python API, common workflows.
- **[docs/ARCHITECTURE.md](docs/ARCHITECTURE.md)** — How the pieces fit together and why.
- **[docs/TROUBLESHOOTING.md](docs/TROUBLESHOOTING.md)** — Common problems and fixes.
- **[docs/BACKGROUND.md](docs/BACKGROUND.md)** — Why we ended up at BiDi (vs Marionette, CDP, Selenium, Playwright).

## Requirements

- Docker + Docker Compose plugin
- An EC2 instance (or any Linux host) with the `sg-firefox` stack able to bind ports 443, 8081, 9222
- Python 3.10+ if you want to use the client class directly outside containers
