# Background

This document records *why* the architecture is what it is, including dead
ends we tried. If you're tempted to "improve" this by switching to Selenium
or routing through Playwright, read this first.

## The original goal

A Python script (running in a sidecar container) needs to programmatically
control the Firefox running inside a `jlesage/firefox` container — navigating
URLs, interacting with pages, extracting data — while a human can
simultaneously watch and interact with the same browser via the noVNC view
that jlesage exposes.

This "shared driver/observer" pattern is genuinely useful: a script can hand
off to a human for captchas, MFA, weird login flows, then resume. You can't
get this from a separate headless browser.

## The dead ends

These were tried and ruled out, in roughly the order they came up. Each one
illustrates a real lesson about Firefox's automation surface in late 2025 /
early 2026.

### 1. Playwright `connect_over_cdp`

Approach: launch Firefox with `--remote-debugging-port=9222`, connect with
`firefox.connect_over_cdp("http://...:9222")`.

Why it fails: Playwright's `connect_over_cdp` is **Chromium-only**. Firefox
has its own protocol. Even if you ignore that:

- Firefox 145 dropped CDP entirely. `--remote-debugging-port` now serves
  WebDriver BiDi, not CDP.
- The port binds 127.0.0.1 only. `--remote-debugging-address=0.0.0.0` is
  silently ignored.

### 2. Marionette directly

Approach: enable Marionette (`marionette.enabled=true`), expose port 2828,
connect a Marionette client.

Why it fails: Marionette's loopback binding is hardcoded. The
`--marionette-host=0.0.0.0` flag is silently ignored. The
`marionette.forceLocal` preference doesn't exist in modern Firefox.

You can use `socat` to relay the port externally, but then:

- Playwright doesn't speak raw Marionette. Playwright uses a *patched*
  Firefox internally and its own protocol. So Marionette + Playwright
  doesn't work.
- Selenium does speak Marionette via geckodriver, but at that point you've
  added another layer (geckodriver) and given up the "single Firefox"
  property — Selenium starts its own Firefox unless you carefully use
  `--connect-existing`.

### 3. Geckodriver `--connect-existing`

Approach: drop a geckodriver binary into the container, start it with
`--connect-existing --marionette-port 2828`, expose its WebDriver HTTP
port (4444) on the docker network, drive with Selenium.

Why we didn't go this way: it works, but adds machinery (geckodriver as a
sidecar process, Selenium dependency) for less-good ergonomics than BiDi
direct. Selenium 4's BiDi support also runs through geckodriver, which is
strictly more setup than just talking BiDi WebSocket directly.

This is a real fallback if BiDi turns out to be too low-level for your
needs. It's what `selenium/standalone-firefox` does internally.

### 4. Playwright `firefox.connect` to a Playwright server

Approach: run `playwright launchServer` as a sidecar that owns its own
Firefox, connect to it via `firefox.connect("ws://...")`.

Why we didn't go this way: it works for the "we want a remotely-driveable
Firefox" goal, but **the human-visible Firefox in jlesage and the
script-driven Firefox would be different processes**. You lose the shared
driver/observer property that motivated the whole exercise.

You could engineer around it (run Playwright server inside the jlesage
container, sharing Xvfb), but at that point you're rebuilding most of
jlesage and you might as well start with the
[playwright-vnc](https://github.com/DmitriyG228/playwright-vnc)
project and add Firefox support yourself.

### 5. Replace `jlesage/firefox` with `selenium/standalone-firefox`

Approach: drop jlesage, use the official Selenium image which packages
Firefox + geckodriver + Xvfb + noVNC.

Why we didn't go this way: it would have worked, but jlesage's
`WEB_AUTHENTICATION`, `FF_PREF_*` env-var system, kiosk-mode support, and
the existing operator workflow are non-trivial to migrate. We chose to
keep jlesage and add minimal augmentation.

Worth considering if you're starting fresh.

## What we landed on, and why

### WebDriver BiDi over WebSocket

BiDi is the modern, cross-browser automation protocol. Firefox's native
support for it is good (it's their strategic post-CDP direction). It's
event-driven, supports network interception, JS evaluation, screenshots,
and is the protocol Selenium 4 / Puppeteer / Playwright are all moving
toward.

By talking BiDi directly:

- No patched browser binary
- No geckodriver
- No Selenium / Playwright dependency
- Single Firefox process, drivable AND human-visible
- One protocol, well-specified, future-proof
- Python client is ~300 lines

### `socat` relay in shared network namespace

Firefox's BiDi binds loopback only and there's no flag to change it. We
need *something* to bridge that loopback to the docker network. The
options were:

- **socat in a sidecar container with `network_mode: "service:firefox"`**
  ✓ Chosen. No image modification, simple compose addition.
- **socat baked into the firefox image as an s6 service.** More robust
  (no namespace-sharing fragility on restart), but requires a custom
  Dockerfile extending jlesage.
- **iptables redirect.** Possible but invasive, requires NET_ADMIN cap.
- **Custom Firefox build with the loopback check removed.** No.

We chose the simplest thing that worked. The s6-service version is a
reasonable evolution if the relay's restart fragility becomes a real
operational issue. There's a hint in the problem statement that this
pattern was already in use for Marionette (PID 1456 socat for port 2828
in the original investigation).

### Host header workaround in the client

Firefox's `--remote-allow-hosts` does exact string matching on the full
`Host:` header value (including port), and silently rejects allowlist
entries that contain colons. So no flag value gets us `Host: firefox:9223`
to be accepted.

The cleanest fix turned out to be in the client: open the TCP socket to
the relay yourself, but tell the WebSocket library a different URL whose
Host header (`localhost:9222`) Firefox does accept. This is a one-time
quirk in `FirefoxBiDi.connect()`, well-commented, with no operational
impact.

Alternatives considered:

- **nginx as a Host-rewriting reverse proxy.** Works, but more moving
  parts (nginx config, second image).
- **Submit a Firefox bug fixing the allowlist parser.** Maybe. Not in
  the short-term plan.

## Why direct BiDi instead of Selenium 4 BiDi

Selenium 4 has BiDi support, but its BiDi commands flow through geckodriver
and Selenium's WebDriver session. To use it you'd run geckodriver in
`--connect-existing` mode against the running Firefox, then drive it with
Selenium.

That's strictly more machinery than just opening a WebSocket and sending
JSON. The BiDi protocol is well-specified and stable. Our wrapper gives us
exactly the abstractions we want without inheriting Selenium's API
opinions.

If you find yourself wanting Selenium-shaped APIs (find_element,
WebDriverWait, etc.), that's a sign you should switch to Selenium 4 with
`--connect-existing`. We didn't because:

- The BiDi protocol gives us more direct control of network interception,
  events, and script evaluation
- We don't need Selenium's element-finding abstractions for our use cases
- Less dependency surface, less version coupling

## What you're giving up

It's worth being explicit about the trade-offs:

- **No element-finding helpers.** No `find_element(By.CSS, ...)`,
  `WebDriverWait`, etc. You write `eval` expressions instead. This is
  more code for simple cases, more flexible for complex ones.
- **No automatic retries.** Selenium has built-in retry/backoff for stale
  references, ajax loads, etc. You'd add those yourself if needed.
- **`navigator.webdriver === true`.** Anti-bot fingerprinting will detect
  this. Selenium has the same issue without extensions.
- **Single session at a time.** Firefox's BiDi only supports one active
  session per browser. We hold one long-lived session in the client
  class. If you need parallelism, run multiple Firefox containers.
- **Limited Python BiDi ecosystem.** The protocol is well-specified, but
  there's no equivalent of `selenium-python` for BiDi yet. Our 300-line
  client is the closest thing.

If any of those become real pain, switch to Selenium 4 + geckodriver
`--connect-existing`. The architecture (jlesage Firefox + relay sidecar)
stays the same; just the client changes.

## References

- WebDriver BiDi spec: https://w3c.github.io/webdriver-bidi/
- Firefox Remote Agent docs:
  https://firefox-source-docs.mozilla.org/remote/index.html
- jlesage/firefox: https://github.com/jlesage/docker-firefox
- The Mozilla `LOOPBACKS.includes(host)` check that hardcodes loopback
  binding lives in the Firefox source under `remote/`.
