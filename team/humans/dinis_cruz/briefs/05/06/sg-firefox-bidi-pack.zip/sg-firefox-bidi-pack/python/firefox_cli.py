"""
firefox_cli.py — Typer CLI for driving Firefox via WebDriver BiDi.

Each subcommand creates its own BiDi session, runs the command, and ends
the session cleanly. That means you can run subcommands back-to-back
from the shell without leaving stale sessions behind.

Examples
--------
    # Set globally for all commands
    export FIREFOX_HOST=firefox
    export FIREFOX_PORT=9223

    # Single commands
    firefox-cli open https://news.ycombinator.com
    firefox-cli title
    firefox-cli url
    firefox-cli html --output page.html
    firefox-cli text
    firefox-cli screenshot --output shot.png --full-page
    firefox-cli eval "document.querySelectorAll('.athing').length"
    firefox-cli cookies

    # Tab management
    firefox-cli contexts
    firefox-cli new-tab --url https://example.com

    # JSON output for piping
    firefox-cli --json title
    firefox-cli --json eval "({hello: 'world', n: 42})"

Pipe-friendly behaviour
-----------------------
By default, output goes to stdout in plain text. Pass --json before the
subcommand to get structured JSON output for every command. Errors go to
stderr with a non-zero exit code.
"""

from __future__ import annotations

import asyncio
import json
import os
import sys
from pathlib import Path
from typing import Annotated, Optional

import typer

from firefox_bidi import BiDiError, FirefoxBiDi


app = typer.Typer(
    add_completion=False,
    no_args_is_help=True,
    help="Drive the Firefox in jlesage/firefox via WebDriver BiDi.",
)

# Module-level state set by main callback so subcommands can read it.
_state: dict = {
    "host": "firefox",
    "port": 9223,
    "json": False,
    "wait": "complete",
}


@app.callback()
def main(
    host: Annotated[
        str,
        typer.Option(
            "--host",
            envvar="FIREFOX_HOST",
            help="Firefox container hostname on the docker network.",
        ),
    ] = "firefox",
    port: Annotated[
        int,
        typer.Option(
            "--port",
            envvar="FIREFOX_PORT",
            help="bidi-relay listen port (the socat sidecar's port).",
        ),
    ] = 9223,
    json_output: Annotated[
        bool,
        typer.Option("--json", help="Output JSON instead of plain text."),
    ] = False,
    wait: Annotated[
        str,
        typer.Option(
            "--wait",
            help="Navigation wait condition: none | interactive | complete.",
        ),
    ] = "complete",
):
    """Connect to Firefox via WebDriver BiDi and run a single command."""
    _state["host"] = host
    _state["port"] = port
    _state["json"] = json_output
    _state["wait"] = wait


# ---------------------------------------------------------------------------
# helpers
# ---------------------------------------------------------------------------


def _emit(value, *, raw: bool = False) -> None:
    """Print a value, respecting the --json flag."""
    if _state["json"]:
        # Use default=str so things like bytes are stringified rather than
        # crashing.  Bytes commands handle their own output anyway.
        typer.echo(json.dumps(value, default=str, indent=2))
        return

    if raw:
        # raw=True means already-stringified (HTML, text); just echo it
        typer.echo(value, nl=False)
        return

    if isinstance(value, (dict, list)):
        typer.echo(json.dumps(value, default=str, indent=2))
    elif isinstance(value, bool):
        typer.echo("true" if value else "false")
    elif value is None:
        typer.echo("null")
    else:
        typer.echo(str(value))


def _run(coro):
    """Run the coroutine and translate BiDi errors into a clean CLI error."""
    try:
        return asyncio.run(coro)
    except BiDiError as e:
        typer.echo(f"BiDi error [{e.error}]: {e.message}", err=True)
        raise typer.Exit(code=2)
    except (ConnectionError, ConnectionRefusedError, OSError) as e:
        typer.echo(f"Connection error: {e}", err=True)
        typer.echo(
            f"Check that the relay is up: "
            f"docker compose ps  (looking for sg-firefox-bidi-relay-1)",
            err=True,
        )
        raise typer.Exit(code=3)


def _client() -> FirefoxBiDi:
    return FirefoxBiDi(host=_state["host"], port=_state["port"])


# ---------------------------------------------------------------------------
# commands
# ---------------------------------------------------------------------------


@app.command()
def open(
    url: Annotated[str, typer.Argument(help="URL to navigate to.")],
):
    """Navigate the current tab to URL. Prints the final URL after redirects."""

    async def go():
        async with _client() as ff:
            return await ff.open_url(url, wait=_state["wait"])

    _emit(_run(go()))


@app.command()
def url():
    """Print the current URL."""

    async def go():
        async with _client() as ff:
            return await ff.get_url()

    _emit(_run(go()))


@app.command()
def title():
    """Print document.title."""

    async def go():
        async with _client() as ff:
            return await ff.get_title()

    _emit(_run(go()))


@app.command()
def html(
    output: Annotated[
        Optional[Path],
        typer.Option("--output", "-o", help="Write HTML to file instead of stdout."),
    ] = None,
):
    """Print or save the page's outerHTML."""

    async def go():
        async with _client() as ff:
            return await ff.get_html()

    result = _run(go())
    if output:
        output.write_text(result, encoding="utf-8")
        typer.echo(f"Wrote {len(result)} chars to {output}", err=True)
    else:
        # In plain mode, dump the HTML raw so it pipes cleanly into files
        # or other tools (no quoting, no JSON wrapping).
        if _state["json"]:
            _emit(result)
        else:
            _emit(result, raw=True)


@app.command()
def text():
    """Print document.body.innerText."""

    async def go():
        async with _client() as ff:
            return await ff.get_text()

    result = _run(go())
    if _state["json"]:
        _emit(result)
    else:
        _emit(result, raw=True)
        # innerText doesn't always end with a newline; add one for terminals
        if not result.endswith("\n"):
            typer.echo()


@app.command(name="eval")
def eval_js(
    expression: Annotated[
        str, typer.Argument(help="JavaScript expression (not a statement).")
    ],
    no_await: Annotated[
        bool,
        typer.Option("--no-await", help="Don't await promises returned by the expression."),
    ] = False,
):
    """
    Evaluate a JS expression in the page and print the result.

    Wrap statements in an IIFE if you need them:
      firefox-cli eval "(() => { let x = 1; return x + 2; })()"
    """

    async def go():
        async with _client() as ff:
            return await ff.eval(expression, await_promise=not no_await)

    _emit(_run(go()))


@app.command()
def screenshot(
    output: Annotated[
        Path,
        typer.Option("--output", "-o", help="Path to write the PNG to."),
    ] = Path("screenshot.png"),
    full_page: Annotated[
        bool, typer.Option("--full-page", help="Capture the whole document, not just the viewport.")
    ] = False,
):
    """Capture a PNG screenshot."""

    async def go():
        async with _client() as ff:
            return await ff.screenshot(full_page=full_page)

    png = _run(go())
    output.write_bytes(png)
    if _state["json"]:
        _emit({"path": str(output), "bytes": len(png)})
    else:
        typer.echo(f"Wrote {len(png)} bytes to {output}")


@app.command()
def reload():
    """Reload the current tab."""

    async def go():
        async with _client() as ff:
            await ff.reload(wait=_state["wait"])
            return await ff.get_url()

    _emit(_run(go()))


@app.command()
def back():
    """Navigate back one entry in history."""

    async def go():
        async with _client() as ff:
            await ff.go_back()
            return await ff.get_url()

    _emit(_run(go()))


@app.command()
def forward():
    """Navigate forward one entry in history."""

    async def go():
        async with _client() as ff:
            await ff.go_forward()
            return await ff.get_url()

    _emit(_run(go()))


@app.command()
def cookies():
    """List cookies visible to the current page."""

    async def go():
        async with _client() as ff:
            return await ff.get_cookies()

    cs = _run(go())
    if _state["json"]:
        _emit(cs)
    else:
        if not cs:
            typer.echo("(no cookies)")
        for c in cs:
            name = c.get("name", "?")
            domain = c.get("domain", "?")
            value = c.get("value", {})
            # cookie values come as a BiDi RemoteValue
            v = value.get("value") if isinstance(value, dict) else value
            typer.echo(f"{name}\t{domain}\t{v}")


@app.command()
def contexts():
    """List all top-level browsing contexts (tabs)."""

    async def go():
        async with _client() as ff:
            return await ff.get_contexts()

    cs = _run(go())
    if _state["json"]:
        _emit(cs)
    else:
        for c in cs:
            ctx_id = c.get("context", "?")
            url_ = c.get("url", "?")
            typer.echo(f"{ctx_id}\t{url_}")


@app.command(name="new-tab")
def new_tab(
    url: Annotated[
        Optional[str],
        typer.Option("--url", help="URL to load in the new tab."),
    ] = None,
):
    """Open a new tab. Prints its context id."""

    async def go():
        async with _client() as ff:
            return await ff.new_tab(url=url)

    _emit(_run(go()))


@app.command(name="close-tab")
def close_tab(
    context: Annotated[str, typer.Argument(help="Context id of the tab to close.")],
):
    """Close a specific tab by context id (see `firefox-cli contexts`)."""

    async def go():
        async with _client() as ff:
            await ff.close_tab(context)
            return {"closed": context}

    _emit(_run(go()))


@app.command()
def session():
    """Print info about the BiDi session and the connected browser."""

    async def go():
        async with _client() as ff:
            ua = await ff.eval("navigator.userAgent")
            ctxs = await ff.get_contexts()
            return {
                "session_id": ff._session_id,
                "user_agent": ua,
                "tab_count": len(ctxs),
                "current_url": ctxs[0]["url"] if ctxs else None,
            }

    _emit(_run(go()))


if __name__ == "__main__":
    app()
