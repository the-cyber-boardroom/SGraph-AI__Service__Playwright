"""
Firefox BiDi client for the sg-firefox stack.

Drives the Firefox running in jlesage/firefox via WebDriver BiDi over WebSocket.
Connection goes through the bidi-relay socat sidecar that exposes Firefox's
loopback-bound Remote Agent on the docker network.

Architectural notes
-------------------
- Firefox's Remote Agent hardcodes loopback-only binding. We can't change that.
- The bidi-relay container runs socat in firefox's network namespace, listening
  on 0.0.0.0:9223 and forwarding to 127.0.0.1:9222.
- Firefox's --remote-allow-hosts flag does exact string matching on the full
  Host header value, and silently rejects entries containing colons. So
  Host: firefox:9223 is rejected even when "firefox:9223" is in the allowlist.
- Workaround: open the TCP socket to the relay directly, but tell the websockets
  library the URL is ws://localhost:9222 so the Host header sent on the upgrade
  matches what Firefox accepts.

Usage
-----
    async with FirefoxBiDi(host="firefox", port=9223) as ff:
        await ff.open_url("https://example.com")
        html = await ff.get_html()
        title = await ff.get_title()
        await ff.eval("document.body.style.background = 'pink'")
"""

from __future__ import annotations

import asyncio
import json
import logging
import socket
from contextlib import asynccontextmanager
from typing import Any

import websockets
from websockets.asyncio.client import ClientConnection

log = logging.getLogger(__name__)


class BiDiError(Exception):
    """Raised when Firefox returns an error response to a BiDi command."""

    def __init__(self, error: str, message: str, stacktrace: str = ""):
        self.error = error
        self.message = message
        self.stacktrace = stacktrace
        super().__init__(f"{error}: {message}")


class FirefoxBiDi:
    """
    Persistent BiDi client. One instance owns one BiDi session against Firefox.

    Firefox only allows a single active BiDi session per browser, so a single
    long-lived FirefoxBiDi instance is the intended pattern. Reconnects are
    expensive (and require ending the previous session first), so don't churn
    instances per task.

    The class is async-context-manager-friendly:

        async with FirefoxBiDi() as ff:
            await ff.open_url("https://example.com")

    Or use it manually:

        ff = FirefoxBiDi()
        await ff.connect()
        try:
            await ff.open_url("https://example.com")
        finally:
            await ff.close()
    """

    def __init__(
        self,
        host: str = "firefox",
        port: int = 9223,
        *,
        spoofed_host_header: str = "localhost:9222",
        connect_timeout: float = 10.0,
    ):
        self._host = host
        self._port = port
        self._spoofed_host_header = spoofed_host_header
        self._connect_timeout = connect_timeout

        self._ws: ClientConnection | None = None
        self._session_id: str | None = None
        self._next_id = 1
        self._pending: dict[int, asyncio.Future[dict[str, Any]]] = {}
        self._event_handlers: dict[str, list] = {}
        self._reader_task: asyncio.Task | None = None
        self._lock = asyncio.Lock()  # serialises send-then-await on _next_id

    # ------------------------------------------------------------------
    # connection lifecycle
    # ------------------------------------------------------------------

    async def connect(self) -> None:
        """Open the WebSocket and create a BiDi session."""
        if self._ws is not None:
            raise RuntimeError("Already connected")

        # Resolve the firefox container's IP synchronously. We need the real IP
        # because the URL we hand to websockets will lie about the destination.
        ip = await asyncio.get_event_loop().run_in_executor(
            None, socket.gethostbyname, self._host
        )
        log.debug("Resolved %s -> %s, connecting to %s:%d", self._host, ip, ip, self._port)

        # Open the TCP socket ourselves, pointed at the relay. Then hand it to
        # websockets along with a URL whose Host (localhost:9222) is what
        # Firefox's --remote-allow-hosts will accept.
        sock = await asyncio.wait_for(
            asyncio.get_event_loop().run_in_executor(
                None, socket.create_connection, (ip, self._port)
            ),
            timeout=self._connect_timeout,
        )

        spoofed_url = f"ws://{self._spoofed_host_header}/session"
        self._ws = await websockets.connect(spoofed_url, sock=sock, server_hostname=None)

        # Start the background reader before we send anything — session.new
        # will need it.
        self._reader_task = asyncio.create_task(self._reader(), name="bidi-reader")

        # Create the BiDi session. We don't pass capabilities since we're
        # attaching to an already-running browser, not requesting a new one.
        result = await self._call("session.new", {"capabilities": {}})
        self._session_id = result["sessionId"]
        log.info("BiDi session created: %s", self._session_id)

    async def close(self) -> None:
        """End the session and close the WebSocket cleanly."""
        if self._ws is None:
            return

        try:
            if self._session_id:
                try:
                    await asyncio.wait_for(self._call("session.end", {}), timeout=5.0)
                except Exception as e:
                    log.warning("session.end failed: %s", e)
        finally:
            self._session_id = None
            if self._reader_task and not self._reader_task.done():
                self._reader_task.cancel()
                try:
                    await self._reader_task
                except (asyncio.CancelledError, Exception):
                    pass
            try:
                await self._ws.close()
            except Exception:
                pass
            self._ws = None

    async def __aenter__(self) -> "FirefoxBiDi":
        await self.connect()
        return self

    async def __aexit__(self, *exc) -> None:
        await self.close()

    # ------------------------------------------------------------------
    # protocol plumbing
    # ------------------------------------------------------------------

    async def _reader(self) -> None:
        """Demux incoming BiDi messages: responses go to futures, events to handlers."""
        assert self._ws is not None
        try:
            async for raw in self._ws:
                try:
                    msg = json.loads(raw)
                except json.JSONDecodeError:
                    log.warning("Non-JSON message: %r", raw[:200])
                    continue

                msg_type = msg.get("type")
                if msg_type in ("success", "error"):
                    mid = msg.get("id")
                    fut = self._pending.pop(mid, None)
                    if fut is not None and not fut.done():
                        fut.set_result(msg)
                    else:
                        log.debug("Unmatched response id=%s: %s", mid, msg)
                elif msg_type == "event":
                    method = msg.get("method", "")
                    handlers = self._event_handlers.get(method, [])
                    for h in handlers:
                        try:
                            res = h(msg.get("params", {}))
                            if asyncio.iscoroutine(res):
                                asyncio.create_task(res)
                        except Exception:
                            log.exception("Event handler for %s failed", method)
                else:
                    log.debug("Unknown message: %s", msg)
        except asyncio.CancelledError:
            raise
        except Exception:
            log.exception("Reader task crashed")
            # Fail any outstanding waiters so callers don't hang forever
            for fut in self._pending.values():
                if not fut.done():
                    fut.set_exception(ConnectionError("BiDi connection lost"))
            self._pending.clear()

    async def _call(self, method: str, params: dict[str, Any] | None = None) -> dict[str, Any]:
        """Send a BiDi command and await its matching response."""
        if self._ws is None:
            raise RuntimeError("Not connected")

        async with self._lock:
            mid = self._next_id
            self._next_id += 1

        fut: asyncio.Future[dict[str, Any]] = asyncio.get_event_loop().create_future()
        self._pending[mid] = fut

        await self._ws.send(json.dumps({"id": mid, "method": method, "params": params or {}}))
        msg = await fut

        if msg.get("type") == "error":
            raise BiDiError(
                error=msg.get("error", "unknown"),
                message=msg.get("message", ""),
                stacktrace=msg.get("stacktrace", ""),
            )
        return msg.get("result", {})

    def on(self, event_method: str, handler) -> None:
        """
        Register a handler for a BiDi event. Handler receives the params dict.

        Note: you also need to call subscribe() to tell Firefox to actually
        emit the event.
        """
        self._event_handlers.setdefault(event_method, []).append(handler)

    async def subscribe(self, events: list[str], contexts: list[str] | None = None) -> None:
        """Subscribe to BiDi events. See https://w3c.github.io/webdriver-bidi/"""
        params: dict[str, Any] = {"events": events}
        if contexts is not None:
            params["contexts"] = contexts
        await self._call("session.subscribe", params)

    # ------------------------------------------------------------------
    # high-level commands
    # ------------------------------------------------------------------

    async def get_contexts(self) -> list[dict[str, Any]]:
        """Return the full browsing context tree (all tabs + their iframes)."""
        result = await self._call("browsingContext.getTree", {})
        return result["contexts"]

    async def current_context(self) -> str:
        """Return the context id of the first top-level tab."""
        contexts = await self.get_contexts()
        if not contexts:
            raise RuntimeError("No browsing contexts found")
        return contexts[0]["context"]

    async def open_url(
        self,
        url: str,
        *,
        context: str | None = None,
        wait: str = "complete",
    ) -> str:
        """
        Navigate to a URL.

        wait: "none" | "interactive" | "complete" — when to consider the
        navigation finished. "complete" waits for the load event.

        Returns the final URL after redirects.
        """
        if context is None:
            context = await self.current_context()
        result = await self._call("browsingContext.navigate", {
            "context": context,
            "url": url,
            "wait": wait,
        })
        return result.get("url", url)

    async def get_url(self, context: str | None = None) -> str:
        """Return the current URL of the given (or default) context."""
        if context is None:
            context = await self.current_context()
        # browsingContext.getTree gives us the URL without needing script eval
        result = await self._call("browsingContext.getTree", {"root": context, "maxDepth": 0})
        return result["contexts"][0]["url"]

    async def get_title(self, context: str | None = None) -> str:
        """Return document.title."""
        return await self.eval("document.title", context=context)

    async def get_html(self, context: str | None = None) -> str:
        """Return document.documentElement.outerHTML for the current page."""
        return await self.eval("document.documentElement.outerHTML", context=context)

    async def get_text(self, context: str | None = None) -> str:
        """Return document.body.innerText."""
        return await self.eval("document.body.innerText", context=context)

    async def eval(
        self,
        expression: str,
        *,
        context: str | None = None,
        await_promise: bool = True,
    ) -> Any:
        """
        Evaluate a JS expression in the page and return the result.

        The expression must be an *expression*, not a statement. If you need
        statements, wrap them: `eval("(() => { let x = 1; return x; })()")`.

        Returns the deserialised value. Complex objects come back as their
        BiDi representation (dicts with "type" + "value"); simple types
        (str, int, bool, None) are unwrapped.
        """
        if context is None:
            context = await self.current_context()
        result = await self._call("script.evaluate", {
            "expression": expression,
            "target": {"context": context},
            "awaitPromise": await_promise,
            "resultOwnership": "none",
        })
        if result.get("type") == "exception":
            details = result.get("exceptionDetails", {})
            raise BiDiError(
                error="script.exception",
                message=str(details.get("text", "Script raised an exception")),
                stacktrace=json.dumps(details, indent=2),
            )
        return _unwrap_remote_value(result.get("result", {}))

    async def screenshot(
        self,
        context: str | None = None,
        *,
        full_page: bool = False,
    ) -> bytes:
        """Capture a screenshot. Returns raw PNG bytes."""
        import base64
        if context is None:
            context = await self.current_context()
        params: dict[str, Any] = {"context": context}
        if full_page:
            params["origin"] = "document"
        result = await self._call("browsingContext.captureScreenshot", params)
        return base64.b64decode(result["data"])

    async def reload(self, context: str | None = None, *, wait: str = "complete") -> None:
        if context is None:
            context = await self.current_context()
        await self._call("browsingContext.reload", {"context": context, "wait": wait})

    async def go_back(self, context: str | None = None) -> None:
        if context is None:
            context = await self.current_context()
        await self._call("browsingContext.traverseHistory", {"context": context, "delta": -1})

    async def go_forward(self, context: str | None = None) -> None:
        if context is None:
            context = await self.current_context()
        await self._call("browsingContext.traverseHistory", {"context": context, "delta": 1})

    async def new_tab(self, url: str | None = None) -> str:
        """Open a new top-level tab. Returns the new context id."""
        result = await self._call("browsingContext.create", {"type": "tab"})
        ctx = result["context"]
        if url:
            await self.open_url(url, context=ctx)
        return ctx

    async def close_tab(self, context: str) -> None:
        await self._call("browsingContext.close", {"context": context})

    async def get_cookies(self, context: str | None = None) -> list[dict[str, Any]]:
        """Return all cookies visible to the current page."""
        if context is None:
            context = await self.current_context()
        result = await self._call("storage.getCookies", {
            "partition": {"type": "context", "context": context},
        })
        return result.get("cookies", [])


def _unwrap_remote_value(remote: dict[str, Any]) -> Any:
    """
    Convert a BiDi RemoteValue back into a Python value where possible.

    See https://w3c.github.io/webdriver-bidi/#type-script-RemoteValue.
    Primitives are unwrapped; complex types are returned as the raw dict
    so the caller has access to all the metadata.
    """
    t = remote.get("type")
    if t == "string":
        return remote.get("value", "")
    if t == "number":
        v = remote.get("value")
        # BiDi may send "Infinity"/"-Infinity"/"NaN" as strings
        if v == "Infinity":
            return float("inf")
        if v == "-Infinity":
            return float("-inf")
        if v == "NaN":
            return float("nan")
        return v
    if t == "boolean":
        return remote.get("value", False)
    if t == "null":
        return None
    if t == "undefined":
        return None
    if t == "bigint":
        return int(remote.get("value", "0"))
    if t == "array":
        return [_unwrap_remote_value(v) for v in remote.get("value", [])]
    if t == "object":
        # BiDi serialises objects as a list of [key, value] pairs
        out = {}
        for entry in remote.get("value", []):
            k_raw, v_raw = entry
            k = _unwrap_remote_value(k_raw) if isinstance(k_raw, dict) else k_raw
            out[k] = _unwrap_remote_value(v_raw)
        return out
    # Anything else (Map, Set, RegExp, Date, Node, etc.) — return raw
    return remote


# ----------------------------------------------------------------------
# Smoke test
# ----------------------------------------------------------------------

async def _demo() -> None:
    import os
    logging.basicConfig(level=logging.INFO, format="%(asctime)s %(levelname)s %(message)s")

    host = os.environ.get("FIREFOX_HOST", "firefox")
    port = int(os.environ.get("FIREFOX_PORT", "9223"))

    async with FirefoxBiDi(host=host, port=port) as ff:
        print(f"connected, session={ff._session_id}")

        url = await ff.open_url("https://example.com")
        print(f"navigated to: {url}")

        print(f"title: {await ff.get_title()}")
        print(f"current url: {await ff.get_url()}")

        text = await ff.get_text()
        print(f"page text (first 200 chars):\n{text[:200]}")

        html = await ff.get_html()
        print(f"html length: {len(html)} chars")

        ua = await ff.eval("navigator.userAgent")
        print(f"user-agent: {ua}")

        png = await ff.screenshot()
        print(f"screenshot: {len(png)} bytes of PNG")


if __name__ == "__main__":
    asyncio.run(_demo())
