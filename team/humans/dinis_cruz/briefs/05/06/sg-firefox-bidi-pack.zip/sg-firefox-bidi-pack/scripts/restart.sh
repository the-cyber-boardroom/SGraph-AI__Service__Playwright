#!/usr/bin/env bash
# restart.sh — restart the Firefox + bidi-relay pair safely.
#
# Why this exists:
#   `docker compose restart firefox` does NOT restart bidi-relay, but the relay
#   shares Firefox's network namespace. When Firefox restarts, the namespace is
#   recreated and the relay's listener silently dies — the container shows as
#   "Up" but socat is bound to a dead namespace.
#
#   This script forces a clean recreate of both, in dependency order.
#
# Usage:
#   ./scripts/restart.sh

set -euo pipefail

COMPOSE_DIR="${COMPOSE_DIR:-/opt/sg-firefox}"
COMPOSE_FILE="${COMPOSE_DIR}/docker-compose.yml"
SUDO="${FFCLI_SUDO-sudo}"

[ -f "$COMPOSE_FILE" ] || { echo "Compose file not found: $COMPOSE_FILE" >&2; exit 1; }

echo "==> Recreating firefox + bidi-relay"
$SUDO docker compose -f "$COMPOSE_FILE" up -d --force-recreate firefox bidi-relay

echo "==> Waiting for BiDi to come back up"
for i in 1 2 3 4 5 6 7 8 9 10; do
    sleep 1
    fx_ok=$($SUDO docker exec sg-firefox-firefox-1 netstat -tln 2>/dev/null | grep -c '127.0.0.1:9222' || true)
    relay_ok=$($SUDO docker exec sg-firefox-firefox-1 netstat -tln 2>/dev/null | grep -c '0.0.0.0:9223' || true)
    if [ "$fx_ok" -ge 1 ] && [ "$relay_ok" -ge 1 ]; then
        echo "==> Both listeners up after ${i}s"
        $SUDO docker exec sg-firefox-firefox-1 netstat -tln 2>/dev/null | grep -E '9222|9223'
        exit 0
    fi
    echo "    waiting (${i}s)..."
done

echo "Timed out waiting for BiDi listeners to come up." >&2
$SUDO docker compose -f "$COMPOSE_FILE" ps
exit 1
