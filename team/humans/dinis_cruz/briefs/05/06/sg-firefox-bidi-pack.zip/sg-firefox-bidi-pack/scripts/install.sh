#!/usr/bin/env bash
# install.sh — bootstrap the sg-firefox BiDi stack.
#
# Run from the root of the unpacked sg-firefox-bidi-pack directory:
#
#     ./scripts/install.sh
#
# What it does:
#   1. Validates docker is available
#   2. Optionally copies docker-compose.yml into /opt/sg-firefox/ (if missing)
#   3. Builds the firefox-cli image
#   4. Starts the stack
#   5. Verifies BiDi is reachable end-to-end
#   6. Prints next steps

set -euo pipefail

# ---- config ----------------------------------------------------------
COMPOSE_DIR="${COMPOSE_DIR:-/opt/sg-firefox}"
COMPOSE_FILE="${COMPOSE_DIR}/docker-compose.yml"
NETWORK="${FFCLI_NETWORK:-sg-firefox_default}"
SUDO="${FFCLI_SUDO-sudo}"

# Colors only when stdout is a tty
if [ -t 1 ]; then
    BOLD=$'\033[1m'; DIM=$'\033[2m'; GREEN=$'\033[32m'
    YELLOW=$'\033[33m'; RED=$'\033[31m'; RESET=$'\033[0m'
else
    BOLD=""; DIM=""; GREEN=""; YELLOW=""; RED=""; RESET=""
fi

step()  { echo "${BOLD}==>${RESET} $*"; }
ok()    { echo "  ${GREEN}✓${RESET} $*"; }
warn()  { echo "  ${YELLOW}!${RESET} $*"; }
fail()  { echo "  ${RED}✗${RESET} $*" >&2; exit 1; }
info()  { echo "  ${DIM}$*${RESET}"; }

# ---- 0. preflight ----------------------------------------------------
step "Preflight checks"

command -v docker >/dev/null 2>&1 || fail "docker is not installed"
ok "docker found: $(docker --version | cut -d, -f1)"

if ! $SUDO docker compose version >/dev/null 2>&1; then
    fail "docker compose plugin not available"
fi
ok "docker compose found"

PACK_ROOT="$(cd "$(dirname "$0")/.." && pwd)"
[ -f "$PACK_ROOT/python/firefox_bidi.py" ] || fail "Pack layout looks wrong; can't find python/firefox_bidi.py"
[ -f "$PACK_ROOT/python/firefox_cli.py" ]  || fail "Pack layout looks wrong; can't find python/firefox_cli.py"
[ -f "$PACK_ROOT/docker/Dockerfile.firefox-cli" ] || fail "can't find docker/Dockerfile.firefox-cli"
ok "Pack layout OK at $PACK_ROOT"

# ---- 1. compose file -------------------------------------------------
step "Compose file at $COMPOSE_FILE"

if [ ! -f "$COMPOSE_FILE" ]; then
    warn "Not found, copying default from pack"
    $SUDO mkdir -p "$COMPOSE_DIR"
    $SUDO cp "$PACK_ROOT/docker/docker-compose.yml" "$COMPOSE_FILE"
    warn "  ↳ EDIT $COMPOSE_FILE to set WEB_AUTHENTICATION_PASSWORD before exposing it!"
else
    ok "Already exists, leaving alone"
    info "If you want to refresh from the pack: cp $PACK_ROOT/docker/docker-compose.yml $COMPOSE_FILE"
fi

# ---- 2. build CLI image ----------------------------------------------
step "Building firefox-cli image"
( cd "$PACK_ROOT" && $SUDO docker build -t firefox-cli -f docker/Dockerfile.firefox-cli . )
ok "firefox-cli image built"

# ---- 3. bring up the stack -------------------------------------------
step "Starting stack from $COMPOSE_FILE"
$SUDO docker compose -f "$COMPOSE_FILE" up -d --force-recreate firefox bidi-relay
ok "Stack up"

step "Waiting for Firefox to settle"
for i in 1 2 3 4 5 6 7 8 9 10; do
    sleep 1
    if $SUDO docker exec sg-firefox-firefox-1 netstat -tln 2>/dev/null | grep -q '127.0.0.1:9222'; then
        ok "Firefox BiDi listening on 127.0.0.1:9222 (after ${i}s)"
        break
    fi
    info "  …waiting (${i}s)"
done

if ! $SUDO docker exec sg-firefox-firefox-1 netstat -tln 2>/dev/null | grep -q '0.0.0.0:9223'; then
    fail "bidi-relay listener (0.0.0.0:9223) not found; check 'docker compose logs bidi-relay'"
fi
ok "bidi-relay listening on 0.0.0.0:9223"

# ---- 4. smoke test ----------------------------------------------------
step "Smoke test: firefox-cli session"
if $SUDO docker run --rm \
    --network "$NETWORK" \
    -e FIREFOX_HOST=firefox \
    -e FIREFOX_PORT=9223 \
    firefox-cli session ; then
    ok "BiDi end-to-end working"
else
    fail "Smoke test failed; see TROUBLESHOOTING.md"
fi

# ---- 5. next steps ---------------------------------------------------
cat <<EOF

${BOLD}All set.${RESET}

To make ffcli available in your shell, add this line to ~/.bashrc:

    source $PACK_ROOT/scripts/ffcli.sh

Then in a new shell:

    ffcli open https://example.com
    ffcli title
    ffcli html -o /tmp/page.html
    ffcli screenshot -o /tmp/shot.png

For Python automation, see python/firefox_bidi.py and the README in docs/.
EOF
